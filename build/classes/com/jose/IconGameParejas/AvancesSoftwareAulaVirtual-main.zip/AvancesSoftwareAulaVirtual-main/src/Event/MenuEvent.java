package Event;

public interface MenuEvent {
    public void menuSelected(int index); 
 }
