# Raven Dashboard

Java Swing Dashboard build with flatlaf look and feel

## Screenshot
<img src="https://github.com/DJ-Raven/raven-dashboard/assets/58245926/355ee850-e8fa-460b-a74e-1c617b18304b" alt="sample dark" width="400"/>&nbsp;
<img src="https://github.com/DJ-Raven/raven-dashboard/assets/58245926/054c33ef-91a1-464d-8f61-78c89571aa20" alt="sample light" width="400"/>
